-module(ex4_seq).
-compile(export_all).
-import(lists, [reverse/1]).

%% start:problem
%%  write a function @lookup(Key, List)@ that returns @{ok, H}@
%% If @H@ is an element of @List@ and @Key@ is the first element in @H@
%% otherwise it returns @no@. Write @remove(Key, L) -> L1@ which
%% removes the first element in @L@ whoes first element is @Key@
%% end:problem

%% start:test
test() ->
    {yes,{a,1,2}} = lookup(a, [{b,2},{a,1,2},{c,2}]),
    no = lookup(d, [{b,2},{a,1,2},{c,2}]),
    [{b,2},{c,2}] = remove(a, [{b,2},{a,1,2},{c,2}]),
    [{b,2},{a,1,2},{c,2}] = remove(x, [{b,2},{a,1,2},{c,2}]),
    hooray.
%% end:test

%% start:hints
%% none
%% end:hints

%% start:solution
lookup(Key, [H|_]) when element(1,H) =:= Key ->
    {yes, H};
lookup(Key, [_|T]) ->
    lookup(Key, T);
lookup(_, []) ->
    no.

remove(Key, [H|T]) when element(1, H) =:= Key ->
    T;
remove(Key, [H|T]) ->
    [H|remove(Key, T)];
remove(_, []) ->
    [].
%% end:solution

