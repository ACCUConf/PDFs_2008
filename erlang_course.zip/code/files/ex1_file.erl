-module(ex1_file).
-compile(export_all).
-export([test/0, foreach_chunk_in_file/3]).

%% start:problem
%%  Write a function
%%   @foreach_chunk_in_file(File, Len, Fun) -> [Fun(Bin)]@</br>
%%   This opens the file and reads into binary chunks @Len@ bytes at a time
%%  for each chunk compute @F(Bin)@ return the list @[F(Bin)]@
%% end:problem

%% start:test
test() ->
    ok = file:write_file("tmp",<<"abcdef">>),
    Id = fun(I) -> I end,
    [<<"abc">>,<<"def">>] = foreach_chunk_in_file("tmp",3, Id),
    [<<"abcd">>,<<"ef">>] = foreach_chunk_in_file("tmp",4, Id),
    [<<"abcdef">>] = foreach_chunk_in_file("tmp",8, Id),
    hooray.
%% end:test

%% start:hints
%% <pre> 
%% filelib:file_size(File) -> Len
%% file:open(File, [read,raw,binary]) -> Handle 
%% file:pread(Handle, Start, Len)  -> {ok, Bin} | eof
%% </pre>
%% end:hints

%% start:solution
foreach_chunk_in_file(File, BlockSize, Fun) ->
    Len = filelib:file_size(File),
    {ok, P} = file:open(File, [read,raw,binary]),
    %% Note numbering starts at 0 not 1
    %% there is a mistake in the book page 225
    L = process_chunks(P, 0, BlockSize, Len, Fun),
    file:close(P),
    L.

process_chunks(P, Start, Len, Max, Fun) ->
    {ok, Bin} = file:pread(P, Start, Len),
    G = Fun(Bin),
    Start1 = Start + Len,
    if
	Start1 >= Max -> [G];
	true -> [G|process_chunks(P, Start1, Len, Max, Fun)]
    end.
%% end:solution

