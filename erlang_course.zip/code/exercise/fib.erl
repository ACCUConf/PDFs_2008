-module(fib).
-compile(export_all).

fib(N) -> fib(1, N, 0, 0).

fib(N, N, A, B) ->
    N + A + B;
fib(M, N, A, B) ->
    fib(M+1, N, B, A+M).

   
    
