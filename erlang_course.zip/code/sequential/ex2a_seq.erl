-module(ex2a_seq).
-export([test/0, number_list/1]).
-import(lists, [seq/2, zip/2]).

test() ->
    [{1,a},{2,b},{3,c}] = number_list([a,b,c]),
    hooray.
%% end:test

number_list(L) -> number_list(L, 1).

number_list([X], N) ->
     [{N, X}];
number_list([H|T], N) ->
     [{N, H} | number_list(T, N+1) ].

