-module(multi_server).

-compile(export_all).

start() -> spawn(fun() -> loop() end).

loop() ->
    receive
	{_Pid, {email, _From, _Subject, _Text} = Email} ->
	    io:format("multi_server:email:~p~n",[Email]),
	    {ok, S} = file:open("inbox", [write,append]),
	    io:format(S, "~p.~n", [Email]),
	    file:close(S);
	{_Pid, {im, From, Text}} ->
	    io:format("Msg (~s): ~s~n",[From, Text]);
	{Pid, {get, File}} ->
	    io:format("multi_server:get:~s~n",[File]),
	    Pid ! {self(), file:read_file(File)};
	Any ->
	    io:format("multi server got:~p~n",[Any])
    end,
    loop().
