-module(universal_server).

-compile(export_all).

batch([A]) ->
    start(list_to_integer(atom_to_list(A))),
    receive after infinity -> void end.

start(Port) ->
    io:format("Starting a universal server on Port:~p~n",[Port]),
    {ok, Listen} = gen_tcp:listen(Port, [binary,{packet,4},
					 {reuseaddr,true},{active,true}]),
    spawn_link(fun() -> par_connect(Listen) end).

par_connect(Listen) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen) end),
    loop(Socket).

loop(Socket) ->
    receive
	{tcp, Socket, Data} ->
	    {apply, Mod, Func, Args} = binary_to_term(Data),
	    Return = apply(Mod, Func, Args),
	    gen_tcp:send(Socket, term_to_binary(Return)),
	    loop(Socket);
	{tcp_closed,_} ->
	    void
    end.
