#!/usr/bin/env python

import re

test_str = 'The name of this file is re_example.py'

rgx = re.compile( '.*re_' )
m = rgx.search( test_str )
if m :
    print 'matched string: ', m.group( 0 )
else :
    print 'no match'
