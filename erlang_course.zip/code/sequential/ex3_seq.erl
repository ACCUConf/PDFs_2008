-module(ex3_seq).
-compile(export_all).
-import(lists, [reverse/1]).

%% start:problem
%% Write functions @one(List)@, @two(List)@, and @three(List)@ that each
%% returns two lists containing the
%% even and odd elements in @List@. Use three different techniques.
%% end:problem

%% start:test
test() ->
    {[2,4],[1,3,5]} = one([1,2,3,4,5]),
    {[2,4],[1,3,5]} = two([1,2,3,4,5]),
    {[2,4],[1,3,5]} = three([1,2,3,4,5]),
    hooray.
%% end:test

%% start:hints
%% Use accumulators, recursion and the @partition@ function in lists.erl
%% end:hints

%% start:solution
%% accumulator
one(L) -> one(L, [], []).

one([H|T], Even, Odd) when H rem 2 =:= 0 -> one(T, [H|Even], Odd);
one([H|T], Even, Odd)                    -> one(T, Even, [H|Odd]);
one([], Even, Odd)                       -> {reverse(Even), reverse(Odd)}.

%% recursion
two([]) -> {[],[]};
two([H|T]) ->
    {Evens, Odds} = two(T),
    case is_even(H) of
	true  -> {[H|Evens], Odds};
	false -> {Evens, [H|Odds]}
    end.

%% list-at-a-time
three(L) ->
    lists:partition(fun is_even/1, L).

is_even(X) when X rem 2 =:= 0 -> true;
is_even(_) -> false.
%% end:solution

