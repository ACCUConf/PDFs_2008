-module(test2).

-compile(export_all).

test() ->
    O = test1:data(),
    file:write_file("out1", term_to_binary(O)),
    {ok, Bin} = file:read_file("out1"),
    O =:= binary_to_term(Bin),
    yes.
