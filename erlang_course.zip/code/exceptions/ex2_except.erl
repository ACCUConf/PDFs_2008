-module(ex2_except).
-compile(export_all).

%% start:problem
%% The BIF @list_to_integer("1234")@ will return @1234@, but exits with a bad argument
%% exception if given a bad string. Write a function @list_to_int(String)@ that returns
%% @{ok, Int)@ or @{error, eBadInt}.
%% end:problem

%% start:test
test() ->
    {ok, 123} = list_to_int("123"),
    {error, eBadInt} = list_to_int("abc"),
    hooray.
%% end:test

%% start:hints
%% @catch@ might be useful...
%% end:hints

%% start:solution
list_to_int(L) ->
    case (catch list_to_integer(L)) of
	{'EXIT', _} ->
	    {error, eBadInt};
	Int ->
	    {ok, Int}
    end.
%% end:solution

