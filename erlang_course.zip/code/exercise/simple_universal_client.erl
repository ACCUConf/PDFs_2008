-module(simple_universal_client).

-export([rpc/3]).

rpc(Host, Port, Query) ->
    case gen_tcp:connect(Host,Port,[binary,{packet,4}]) of
	{ok, Socket} ->
	    gen_tcp:send(Socket, term_to_binary(Query)),
	    receive
		{tcp, Socket, Data} ->
		    gen_tcp:close(Socket),
		    {ok, binary_to_term(Data)};
		{tcp_closed, Socket} ->
		    {error, unknown}
	    end;
	{error, _} = Error ->
	    Error
    end.
