-module(pico_dns).

-compile(export_all).

-include("pico_dns.hrl").

-export([start/0, start/1]).

%% A DNS like service

start() -> start(?SERVER_PORT).

start(Port) -> register(?MODULE, spawn(fun() -> run(Port) end)).

run(Port) ->
    io:format("Starting a (pico) dns server on Port=~p~n",[Port]),
    case gen_udp:open(Port, [binary]) of
	{ok, Socket} ->
	    Self = self(),
	    spawn_link(fun() -> ticker(Self) end),
	    loop(Socket, 0, []);
	Error ->
	    io:format("cannot open port 2008 ~p~n",[Error]),
	    exit(oops)
    end.

loop(Socket, N, L) ->
    receive
	tick ->
	    L1 = remove_old_data(N, L),
	    io:format("Time ~p ~p~n",[N,L1]),
	    loop(Socket, N+1, L1);
	{udp, Socket, IP, Port, Bin} ->
	    Term = binary_to_term(Bin),
	    io:format("Term=~p~n",[Term]),
	    case Term of
		{register,Name,Port1,TTL} ->
		    T1 = N + TTL,
		    L1 = insert(T1, Name, {IP, Port1}, L),
		    loop(Socket, N, L1);
		{whereis, Name} ->
		    Val = lookup(Name, L),
		    Ret = adjust_ttl(Val, N),
		    gen_udp:send(Socket, IP, Port, term_to_binary(Ret)),
		    loop(Socket, N, L);
		X ->
		    io:format("dropping:~p~n",[X]),
		    loop(Socket, N, L)
	    end;
	Other ->
	    io:format("dropping:~p~n",[Other]),
	    loop(Socket, N, L)
    end.

%%----------------------------------------------------------------------

ticker(Pid) ->
    receive
    after 1000 ->
	    Pid ! tick,
	    ticker(Pid)
    end.

%%----------------------------------------------------------------------

remove_old_data(T1, [{T2,_,_}|T]) when T1 > T2 -> remove_old_data(T1, T);
remove_old_data(_, L) -> L.

lookup(Name, [{Time,Name,Info}|_]) -> {ok,{Info,Time}};
lookup(Name, [_|T])                -> lookup(Name, T);
lookup(_, [])                      -> lost.

insert(Time, Name, Info, [{T1,_,_,_}=H|T]) when  T1 > Time ->
    [{Time,Name,Info},H|T];
insert(Time, Name, Info, [H|T]) ->
    [H|insert(Time, Name, Info, T)];
insert(Time, Name, Info, []) ->
    [{Time,Name,Info}].
    
adjust_ttl({ok, {_, TTL}}, N) when N > TTL -> lost;
adjust_ttl({ok, {{IP,Port}, TTL}}, N) -> {ok, {IP,Port,TTL-N}};
adjust_ttl(lost, _)              -> lost.
