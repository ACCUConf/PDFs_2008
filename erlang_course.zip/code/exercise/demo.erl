-module(demo).
-compile(export_all).

server() ->
    {"localhost", 1234}.

make_web_server() ->
    %% make a bad version of the code 
    make(bad_code),
    make_web_server("localhost", 1234).

fix_bug_on_web_server() ->
    Host = "localhost",
    Port = 1234,
    io:format("Fixing bug in:~p~n",[Host]),
    S = connect(Host, Port),
    io_format(S, "\nTaking over your machine~n", []),
    make(good_code),
    case install_code(S, jalib_web) of
	{ok,{error,not_purged}} ->
	    io_format(S, "Purging ...~n", []),
	    rpc(S, {apply, erlang, purge_module, [jalib_web]}),
	    install_code(S, jalib_web);
	_ ->
	    void
    end,
    io_format(S, "\nFixing bug in web server~n",[]),
    close(S),
    init:stop().


make_web_server(Host, Port) ->
    io:format("Installing a web server on:~p port:~p~n",
	      [Host, Port]),
    {ok, S} = connect(Host, Port),
    io_format(S, "\nTaking over your machine~n", []),
    install_code(S, jalib_http_driver),
    install_code(S, jalib_web),
    io_format(S, "\nStarting a web server on Port:~w~n",[Port]),
    rpc(S,{apply,jalib_web,run,[Port]}),
    close(S).

%% install code for the module Mod
%% on the machine connected to the socket S


install_code(S, Mod) ->
    io_format(S, "Installing:~p~n",[Mod]),
    {ok, Bin} = file:read_file(atom_to_list(Mod) ++ ".beam"),
    Val = rpc(S, {apply, erlang, load_module, [Mod, Bin]}),
    io:format("loading ~p => ~p~n",[Mod, Val]),
    Val.

connect(Host, Port) ->
    {ok, Socket} = gen_tcp:connect(Host,Port,[binary,{packet,4}]),
    Socket.

io_format(S, Str, Args) ->
    rpc(S, {apply, io, format,[Str,Args]}).

close(Socket) ->
    gen_tcp:close(Socket).

rpc(Socket, Query) ->
    ok = gen_tcp:send(Socket, term_to_binary(Query)),
    receive
	{tcp, Socket, Data} ->
	    binary_to_term(Data);
	{tcp_closed, Socket} ->
	    exit(eSocketClosed)
    end.

make(bad_code) ->
    %% the bad version of the code
    copy("jalib_web_bad.in", "jalib_web.erl"),
    compile:file("jalib_web.erl");
make(good_code) ->
    %% the good version of the code
    copy("jalib_web_good.in", "jalib_web.erl"),
    compile:file("jalib_web.erl").

copy(In, Out) ->
    {ok, Bin} = file:read_file(In),
    file:write_file(Out, Bin).


