-module(dns_coordinate_server_var_port).

%% same as dns_coordinate_server.erl
%%   with a slight twist that we allocate a port
%%   instead of giving the progrsm a fixed
%%   port. This is a good idea since we don't
%%   always know if we can allocate a fixed port

-compile(export_all).

test() ->
    start(joe, {23,10}).

start(Name, Info) ->
    spawn_link(fun() -> run(Name, Info) end).

run(Name, Info) ->
    {ok, Listen} = gen_tcp:listen(0, [binary,{packet,4},
				      {reuseaddr,true},{active,true}]),
    {ok, PortL} = inet:port(Listen),
    io:format("Registering name:~p on port:~p~n",[Name,PortL]),
    pico_resolver:signon(Name, PortL, 30),
    %% spawn a connector
    spawn_link(fun() -> par_connect(Listen, Info) end),
    %% We have to sleep here otherwise the processes will terminate
    %% and the Listen socket will be closed 
    sleep(infinity).

%% page 248
par_connect(Listen, Info) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen, Info) end),
    loop(Socket, Info).

loop(Socket, Info) ->
    receive
	{tcp, Socket, Data} ->
	    whereAreYou = binary_to_term(Data),
	    gen_tcp:send(Socket, term_to_binary(Info)),
	    loop(Socket, Info)
    end.

sleep(T) ->
    receive
    after T ->
	    void 
    end.
