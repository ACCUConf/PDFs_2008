#!/usr/bin/env python
# arg12.py

import argparse

total = 0
words = []

def call_func( arg ) :
    global total, words
    print 'call_func arg:', arg
    try :
        i = int( arg )
        total += i
    except ValueError :
        words.append( arg )
    return None

parser = argparse.ArgumentParser()
parser.add_argument( '-c', type=call_func, nargs='+')
values = parser.parse_args()
print values.c
print total, repr( ' '.join( words ) )
