-module(dns_coordinate_client).

-export([test/0, ask/1, ask/2]).

test() ->
    Name = joe,
    Val = ask(Name),
    io:format("Query result=~p~n",[Val]),
    init:stop().

ask(Name) ->
    io:format("Looking up:~p in DNS~n", [Name]),
    case pico_resolver:locate(Name) of
	{ok, {IP, Port,TTL}} ->
	    io:format("~p found IP=~p Port=~p TTL=~p~n",
		      [Name,IP,Port,TTL]),
	    ask(IP, Port);
	lost ->
	    lost
    end.

ask(IP, Port) ->
    case gen_tcp:connect(IP,Port,[binary,{packet,4}]) of
	{ok, Socket} ->
	    gen_tcp:send(Socket, term_to_binary(whereAreYou)),
	    receive
		{tcp, Socket, Data} ->
		    gen_tcp:close(Socket),
		    {ok, binary_to_term(Data)};
		{tcp_closed, Socket} ->
		    {error, unknown}
	    end;
	{error, _} = Error ->
	    Error
    end.
