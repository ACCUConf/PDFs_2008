#!/usr/bin/env python
# arg9.py

import argparse

def print_num( num ) :
    print( "num = %03i" % num )
def do_process( msg='' )  :
    print( "This is the process function: %s" % msg )

parser = argparse.ArgumentParser()
parser.add_argument( '-i', action='store', dest='num', type=int,
                           choices=(1,2,5,),
                           help='no of items to process',
                 )
parser.add_argument( '-p', action='store', dest='proc_msg',
                         default='ouch',
                         help='message to be processed',
                 )
values = parser.parse_args()
if values.num :
    print_num( values.num )
if values.proc_msg :
    do_process( values.proc_msg )
