-module(ex_doubler).
-compile(export_all).

%% start:problem
%%
%% * write @ex_doubler:double(X) -> 2*X@
%% * (this just tests you can enter and compile a program)
%%
%% end:problem


%% start:test
test() ->
    4 = double(2),
    hooray.
%% end:test

%% start:solution

double(X) -> 2 * X.

%% end:solution

