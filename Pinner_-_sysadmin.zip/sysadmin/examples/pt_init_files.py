#!/usr/bin/env python

"""
pt_init_files.py

script to initialise PayThyme files.

Must be run from the appropriate payroll's data directory

"""

import os
import thymebase
from thymedefs import CREATE
import shutil

all_files = ( 'SSPpaymt', 'adoption', 'diary', 'eeadjtd', 'eeadjust',
              'eeaeo', 'eeaeotd', 'eep11', 'emp_td', 'employee', 'grades',
              'maternity', 'nomcodes', 'p11aeo', 'p11rates', 'p32',
              'paternity', 'payroll', 'payslips', 'sickness', 'slevent',
              'suppcodes', 'sxpdiary', 'sxppaymt', 'taxcr', 'taxcrprd',
              'adjust', 'payformats', 'qdaypatt', 'departments',
              'sections', 'p14', 'p35', 'eeni', 'p11eeni',
            )

base_files = ( 'adjust', 'password', 'qdaypatt', 'payroll', 'payslips', )

# -----------------------------------------------------------------------------

def nuke_files( files ) :
    """Create the required files"""

    os.umask( 7 )

    for file in files :
        f = thymebase.newdb( file, CREATE )
        f.close()

    if os.name != 'nt':
        os.system( 'chmod -R g+w .' )

    return

# -----------------------------------------------------------------------------

def populate_files( files ) :
    """Copy required files from basedata prototypes"""

    for db in files:
        for ext in 'taf', 'tdf', 'tkf':
            basename = db + "." + ext
            shutil.copy('../../basedata/' + basename, basename)
    return

# *****************************************************************************

if __name__ == '__main__':
    nuke_files( all_files )
    populate_files( base_files )

# *****************************************************************************

#  eof  pt_init_files.py
