#!/usr/bin/env python
# arg10.py

import sys, argparse

parser = argparse.ArgumentParser( description='say something to the kids' )

parser.add_argument( 'children', metavar='child',
                      nargs='+', help='the kid to be spoken to' )

parser.add_argument( '--out', type=argparse.FileType( 'w' ),
                              default=sys.stdout,
                              help='the file to write the message to '
                              '(default: standard output)'
                 )
values = parser.parse_args()
values.out.write( 'Mummy and Daddy say goodnight to %s\n' \
                  % ' and '.join(values.children))
values.out.close()
