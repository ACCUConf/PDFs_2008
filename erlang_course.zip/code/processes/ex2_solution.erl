-module(ex2_solution).
-compile(export_all).

test() ->
    timer:tc(ex2_solution, run, []).

run() ->
    Promise1 = promise(fun() -> fib(36) end),
    Promise2 = promise(fun() -> fib(30) end),
    Promise3 = promise(fun() -> fib(15) end),
    610 = yield(Promise3),
    832040 = yield(Promise2),
    14930352 = yield(Promise1),
    true.
    
fib(1) -> 1;
fib(2) -> 1;
fib(N) -> fib(N-1) + fib(N-2).

promise(Fun) ->
    S = self(),
    spawn(fun() ->
		  S ! {self(), Fun()}
	  end).

yield(Pid) ->
    receive
	{Pid, Any} ->
	    Any
    end.

     

    

