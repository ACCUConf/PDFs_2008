-module(double).
-export([double/1]).
%START:body

double(Value) -> Value * Value.
%END:body