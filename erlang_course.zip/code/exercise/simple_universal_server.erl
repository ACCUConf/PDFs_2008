-module(simple_universal_server).

-compile(export_all).

start(Port, Fun) ->
    io:format("Starting a universal server on Port:~p~n",[Port]),
    {ok, Listen} = gen_tcp:listen(Port, [binary,{packet,4},
					 {reuseaddr,true},{active,true}]),
    spawn_link(fun() -> par_connect(Listen, Fun) end).

par_connect(Listen, Fun) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen, Fun) end),
    loop(Socket, Fun).

loop(Socket, Fun) ->
    receive
	{tcp, Socket, Data} ->
	    X = binary_to_term(Data),
	    gen_tcp:send(Socket, term_to_binary(Fun(X))),
	    loop(Socket, Fun);
	{tcp_closed,_} ->
	    void
    end.
