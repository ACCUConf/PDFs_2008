-module(middle_man).

-export([start/2]).

start(Pid, Socket) ->
    process_flag(trap_exit, true),
    io:format("middle man starting~nPid=~p Socket=~p~n",
	      [Pid, Socket]),
    loop(Pid, Socket).

loop(Pid, Socket) ->
    receive
        {Pid, Msg} ->
	    io:format("MM send term:~p~n",[Msg]),
            gen_tcp:send(Socket, term_to_binary(Msg)),
            loop(Pid, Socket);
        {tcp, Socket, Data} ->
	    Term = binary_to_term(Data),
            Pid ! {self(), Term},
	    io:format(" MM received:~p~n",[Term]),
            loop(Pid, Socket);
        {'EXIT', Pid, Why} ->
	    io:format("local process terminated reason(~p):~n",[Why]),
            gen_tcp:close(Socket);
        {tcp_closed, Socket} ->
	    io:format("remote process closed socket~n"),
	    exit(Pid, socket_closed);
	Any ->
	    io:format("Unexpected signal:~p~n",[Any]),
	    loop(Pid, Socket)
    end.
