-module(multi_cs).
-compile(export_all).

%% How message of the day, HTTP, Instant messaging, ftp, and email
%% would have been written in Erlang

test() ->
    multi_cs:mod(),
    multi_cs:get("multi_cs.erl"),
    multi_cs:im("joe", "Hello"),
    multi_cs:email("joe","hi dave","fun stuff").

batch() ->
    simple_universal_server:start(1234, fun trace_then_doit/1),
    receive after infinity -> true end.

trace_then_doit(X) ->
    io:format("Do:~p~n",[X]),
    doit(X).

doit(messageOfTheDay)     -> "Last day of prag studio";
doit({get,File})          -> file:read_file(File);
doit({post,File,Content}) -> file:write(File, Content);
doit(pwd)                 -> file:get_cwd();
doit(ls)                  -> file:list_dir(".");
doit({instantMessage,From,Text}) ->
    io:format("Message:~s ~s~n",[From, Text]),
    messageSent;
doit({email, From, Subject,Text}) ->
    {ok, S} = file:open("inbox",[write,append]),
    io:format(S, "~p~n.",[{date(),time(),From,Subject,Text}]),
    file:close(S),
    emailDeliveredOk;
doit(_) ->
    no.

mod()                    -> do(messageOfTheDay).
get(File)                -> do({get, File}).
post(File, Content)      -> do({post, File, Content}).
pwd()                    -> do(pwd).
ls()                     -> do(ls).
im(From,Text)            -> do({instantMessage, From, Text}).
email(From,Subject,Text) -> do({email,From,Subject,Text}).

do(Q) -> simple_universal_client:rpc("localhost",1234,Q).

%% live code rmi here :-)
