-module(test3).

-compile(export_all).

test() ->
    T = {host,"www.xx.yy.se", port, 2345},
    term2consultable_file("file1", T),
    file:consult("file1").

term2consultable_file(File, Term) ->
    {ok, S} = file:open(File, [write]),
    io:format(S, "~p.~n",[Term]),
    file:close(S).
