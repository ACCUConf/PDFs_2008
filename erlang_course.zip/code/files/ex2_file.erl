-module(ex2_file).
-compile(export_all).
-import(lists, [reverse/1]).

%% problem
%%  Write a function
%%   @spec premove_nl(Str) -> Str. 
%%     possibly remove nl - remove nl at end of string if there is one
%%   @spec file2lines(File) -> [Line]
%%   This opens the file and reads into lines
%% end

%% test cases
test() ->
    "abc" = premove_nl("abc\n"),
    "abc" = premove_nl("abc"),
    ok = file:write_file("tmp",["abc\ndef"]),
    ["abc","def"] = file2lines_slow("tmp"),
    ["abc","def"] = file2lines_fast("tmp"),
    hooray.

id(I) -> I.
%% end

%% hints
%%   filelib:file_size(File) -> Len
%%   file:open(File, [read,raw,binary]) -> Handle 
%%   file:pread(Handle, Start, Len)  -> {ok, Bin} | eof
%% end

%% solution
file2lines_slow(File) ->
    {ok, S} = file:open(File, read),
    L = loop(S),
    file:close(S),
    L.

loop(S) ->
    case io:get_line(S, '') of
	eof -> [];
	Str -> 
	    [premove_nl(Str)|loop(S)]
    end.

premove_nl([$\n]) -> [];
premove_nl([H|T]) -> [H|premove_nl(T)];
premove_nl([]) -> [].

file2lines_fast(File) ->    
    {ok, Bin} = file:read_file(File),
    split_into_lines(binary_to_list(Bin), []).

split_into_lines([], L) ->
    reverse(L);
split_into_lines(Str, L) ->
    {Line, Rest} = get_line(Str, []),
    split_into_lines(Rest, [Line|L]).

get_line([$\n|T], L) -> {reverse(L), T};
get_line([H|T], L)   -> get_line(T, [H|L]);
get_line([], L)      -> {reverse(L), []}.
%% end
