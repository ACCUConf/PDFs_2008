-module(ex1_seq).
-export([test/0]).
-import(lists, [reverse/1, reverse/2]).

%% start:test
test() ->
    In = "A **~~emphasised~~bold** expression",
    Out = "A <b><strike>emphasised</strike>bold</b> expression",
    Out = wikify(In),
    hooray.
%% end:test

%% start:solution
wikify(Str) -> wikify(Str, [], []).

wikify("**" ++ T, [b|S], L) ->
    wikify(T, S, reverse("</b>", L));
wikify("**" ++ T, S, L) ->
    wikify(T, [b|S], reverse("<b>", L));
wikify("~~" ++ T, [strike|S], L) ->
    wikify(T, S, reverse("</strike>", L));
wikify("~~" ++ T, S, L) ->
    wikify(T, [strike|S], reverse("<strike>", L));
wikify([H|T], S, L) ->
    wikify(T, S, [H|L]);
wikify([], [], L) ->
    reverse(L).
%% end:solution
