-module(simple_coordinate_client).

-export([start/0, ask/2]).

start() ->
    IP = "localhost", Port=1234,
    io:format("Requesting data from ~p Port: ~p~n",[IP,Port]),
    Val = ask(IP, Port),
    io:format("Result=~p~n",[Val]),
    init:stop().

ask(IP, Port) ->
    case gen_tcp:connect(IP,Port,[binary,{packet,4}]) of
	{ok, Socket} ->
	    gen_tcp:send(Socket, term_to_binary(whereAreYou)),
	    io:format("waiting:~n"),
	    receive
		{tcp, Socket, Data} ->
		    gen_tcp:close(Socket),
		    {ok, binary_to_term(Data)};
		{tcp_closed, Socket} ->
		    {error, unknown}
	    end;
	{error, _} = Error ->
	    Error
    end.
