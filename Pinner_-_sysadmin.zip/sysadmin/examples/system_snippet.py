#!/usr/bin/env python
# system_snippet.py

import os

tgt = '../../../sessions'

cmd = 'cd %s;xterm -e "ls -lrt|less"' % tgt

os.system( cmd )
