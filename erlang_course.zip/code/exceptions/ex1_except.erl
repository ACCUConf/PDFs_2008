-module(ex1_except).
-compile(export_all).
-include_lib("kernel/include/file.hrl").

%% start:problem
%%<div style="font-size: 80%">
%% Let's practice both error handling and records. The BIF @file:read_file_info(Name)@ 
%% returns either @{ok,#file_info}@
%% or @{error,...}@. Include the definition of @#file_info@ with<br/>
%% @-include_lib("kernel/include/file.hrl")@.
%%
%% * write a function @file_size1(File)@ that returns the size of a file, 
%% or exits if the file is missing.
%% * write @file_size2(File)@ that exits with reason @eNoCanDo@ if the file is missing.
%%
%%</div>
%% end:problem

%% start:test
test() ->
    14 = (catch file_size1("testfile")),
    {'EXIT', _} = (catch file_size1("unknown_file")),
    14 = (catch file_size2("testfile")),
    {'EXIT', eNoCanDo} = (catch file_size2("unknown_file")),
    hooray.
%% end:test

%% start:hints
%% end:hints

%% start:solution
file_size1(FileName) ->
    { ok, #file_info{size=Size} } = file:read_file_info(FileName),
    Size.

file_size2(FileName) ->
    case file:read_file_info(FileName) of
        { ok, #file_info{size=Size} } -> Size;
        { error, enoent }             -> exit(eNoCanDo)
    end.
%% end:solution

