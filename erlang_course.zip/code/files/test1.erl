-module(test1).

-compile(export_all).
-import(lists, [map/2]).

test() -> file:write_file("matrix", data()).

data() -> matrix_to_html([["1","2"],["3","4"],["5","6"]]).

matrix_to_html(Matrix) ->
    [<<"<table>\n">>,
     map(fun(Row) ->
		 [<<"<tr>\n">>,
		  map(fun(Col) -> [<<"<td>">>,Col,<<"</td>\n">>] end, Row),
		  <<"</tr>\n">>]
	 end, Matrix),
     <<"</table>">>].
