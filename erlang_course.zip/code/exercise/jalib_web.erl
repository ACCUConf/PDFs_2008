-module(jalib_web).
-compile(export_all).
-import(lists, [member/2]).
-import(jalib_http_driver, [send_file/3, show/1]).

%% good version of jalib_web

%% try web_server:start()

run(Port) ->
    spawn(fun() -> start(Port) end).

start() -> start(2045).

start(Port) ->
    jalib_http_driver:start(Port,  fun doit/5, docroot()),
    receive
	after infinity ->
		die
	end.

docroot() -> "".

doit(A,B,C,D,E) -> ?MODULE:handle_request(A,B,C,D,E).

handle_request(_Cmd, "/", _Args, _Data, _DocRoot) ->
    {400, "Text/html", ["<h1>I'm a web server - horray</h1>"]};
handle_request(Cmd, File, Args, Data, DocRoot) ->
    %% fixed the error
    {400, "Text/html",
     ["<h1>Horray - the bug is fixed</h1>",
      show({cmd,Cmd,file,File,args,Args,data,Data,docroot,DocRoot})]}.



    
