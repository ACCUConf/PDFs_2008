-module(mobile_code).
-compile(export_all).

-import(universal_client, [connect/2, do/2,close/1]).

test() ->  make_web_server("localhost", 1234, 8000).

fix() ->  fix_web_server("localhost", 1234).

make_web_server(IP, Port, HTTP_port) ->
    io:format("Installing a web server on:~p port:~p~n",
	      [IP, HTTP_port]),
    {ok, S} = connect(IP, Port),
    io_format(S, "\nTaking over your machine~n", []),
    do(copy,jalib_web_bad,to,jalib_web,and_compile_it),
    install_code(S, jalib_http_driver),
    install_code(S, jalib_web),
    io_format(S, "\nStarting a web server on Port:~w~n",[HTTP_port]),
    do(S,{apply,jalib_web,run,[HTTP_port]}),
    close(S),
    init:stop().

fix_web_server(IP, Port) ->
    io:format("Fixing bug on machine:~p~n",[IP]),
    {ok, S} = connect(IP, Port),
    io_format(S, "\nTaking over your machine~n", []),
    do(copy,jalib_web_good,to,jalib_web,and_compile_it),
    case install_code(S, jalib_web) of
	{ok,{error,not_purged}} ->
	    io_format(S, "Purging ...~n", []),
	    do(S, {apply, erlang, purge_module, [jalib_web]}),
	    install_code(S, jalib_web);
	_ ->
	    void
    end,
    io_format(S, "\nFixing bug in web server~n",[]),
    close(S),
    init:stop().

io_format(S, Str, Args) ->
    do(S, {apply, io, format,[Str,Args]}).

install_code(S, Mod) ->
    io_format(S, "Installing:~p~n",[Mod]),
    {ok, Bin} = file:read_file(atom_to_list(Mod) ++ ".beam"),
    Val = do(S, {apply, erlang, load_module, [Mod, Bin]}),
    io:format("loading ~p => ~p~n",[Mod, Val]),
    Val.

do(copy,In,to,Out,and_compile_it) ->
    Fin = atom_to_list(In) ++ ".in",
    Fout = atom_to_list(Out) ++ ".erl",
    io:format("copying: ~s to: ~s~n",[Fin, Fout]),
    copy(Fin, Fout),
    io:format("compiling: ~s~n",[Fout]),
    {ok, _} = compile:file(Fout).

copy(In, Out) ->
    {ok, Bin} = file:read_file(In),
    file:write_file(Out, Bin).

    
