-module(math3).
-compile(export_all).

test() ->
    10 = sum([1,2,3,4]).

    
    
