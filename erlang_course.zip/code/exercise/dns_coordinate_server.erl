-module(dns_coordinate_server).

-compile(export_all).

test1() ->
    Name = joe,
    Port = 1234,
    Info = {joe, 23, 10},
    start(Name, Port, Info).

test2() ->
    Name = dave,
    Port = 4321,
    Info = {dave, 46, 19},
    start(Name, Port, Info).

start(Name, Port, Info) ->
    io:format("Starting a coordinate server on Port:~p~n",[Port]),
    io:format("My information is: ~p~n",[Info]),
    spawn_link(fun() -> run(Name, Port, Info) end).

run(Name, Port, Info) ->
    {ok, Listen} = gen_tcp:listen(Port, [binary,{packet,4},
					 {reuseaddr,true},{active,true}]),
    io:format("Registering name:~p on port:~p~n",[Name,Port]),
    pico_resolver:signon(Name, Port, 30),
    %% spawn a connector
    spawn_link(fun() -> par_connect(Listen, Info) end),
    %% We have to sleep here otherwise the processes will terminate
    %% and the Listen socket will be closed 
    sleep(infinity).

%% page 248
par_connect(Listen, Info) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen, Info) end),
    loop(Socket, Info).

loop(Socket, Info) ->
    receive
	{tcp, Socket, Data} ->
	    whereAreYou = binary_to_term(Data),
	    gen_tcp:send(Socket, term_to_binary(Info)),
	    loop(Socket, Info)
    end.

sleep(T) ->
    receive
    after T ->
	    void 
    end.
