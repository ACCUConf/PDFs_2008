-module(nth).
-compile(export_all).

%% start:problem
%%  Write a function @nth(N, List)@ to return the @Nth@ element of list @List@
%% end:problem

%% start:test
test() ->
    3 = nth(4, [1,1,2,3,5,8,13]),
    b = nth(2, [a,b,c]),
    {'EXIT',_} = (catch nth(4,[a,b])),
    horray.
%% end:test

%% start:hints
%% @nth(3, [a, b, c])@ is the same as @nth(2, [b, c])@
%% end:hints

%% start:solution

nth(1, [H|_]) -> H;
nth(N, [_|T]) -> nth(N-1, T).

%% end:solution
