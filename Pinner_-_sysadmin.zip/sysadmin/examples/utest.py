#!/usr/bin/env python
"""unittest demo"""

# A function to test, it has an error

def oper( op, num1, num2, ) :
    """carry out operation on two numbers"""
    if op == '+' :
        return num1 + num2
    elif op == '-' :
        return num1 - num2
    elif op == '*' :
        return num1 * num2
    elif op == '/' :
        return num1 * num2
    raise RuntimeError, 'invalid operation %s' % op

# a simple unittest test harness

import unittest

class operTestCase( unittest.TestCase ) :
    """This is a TestCase which unittest will instantiate"""
    def testOper( self ) :
        """The unittest will run all test methods"""
        self.assertEquals( oper( '+', 1, 2, ), 3 )
        self.assertEquals( oper( '-', 1, 2, ), -1 )
        self.assertEquals( oper( '*', 1, 2, ), 2 )
        self.assertEquals( oper( '/', 1, 2, ), 0 )

if __name__ == '__main__' :
    unittest.main()

