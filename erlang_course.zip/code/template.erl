-module(template).
-compile(export_all).

%% problem
%% end


%% test cases
test() ->
    horray.
%% end

%% hints
%% end

%% solution
%% end
