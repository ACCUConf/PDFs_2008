-module(ex1_proc).
-compile(export_all).

%% START:test
test() ->
    {Time, _} = timer:tc(ex1_proc, run, []),
    true = timeing_error(Time, 1200) < 0.5,
    hooray.

timeing_error(T1, T2) ->
    io:format("T1 T2=~p ~p~n",[T1, T2]),
    (abs(T1 div 1000 -T2)/T2) * 100.

run() ->
    alarm(self(), hello, 1200),
    receive
	hello ->
	    true
    end.

alarm(Pid, Msg, When) ->
%%    you write the rest ...
%% END:test
    spawn(fun() ->
		  receive
		      after
			  When ->
			      Pid ! Msg
		      end
	  end).

    

