-module(ex2_seq).
-export([test/0, number_list/1]).
-import(lists, [seq/2, zip/2]).

test() ->
    [{1,a},{2,b},{3,c}] = number_list([a,b,c]),
    hooray.
%% end:test

number_list(L) ->
    zip(seq(1,length(L)), L).
