%%%-------------------------------------------------------------------
%%% File    : server1.erl
%%% Author  : joe armstrong <joe@joe-armstrongs-computer.local>
%%% Description : 
%%%
%%% Created : 16 Dec 2007 by joe armstrong <joe@joe-armstrongs-computer.local>
%%%-------------------------------------------------------------------
-module(auction).
-behaviour(gen_server).
%% API
-export([start_link/0]).

%% gen_server callbacks
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
	 terminate/2, code_change/3]).

-record(state, {}).

%% start:api
-export([sell/2, bid/3, list/0]).

-import(lists, [reverse/2]).

-define(SERVER, ?MODULE).

sell(Obj, Time)      -> gen_server:call(?SERVER, {sell, Obj, Time}).
bid(Who, Obj, Price) -> gen_sever:call(?SERVER, {bid, Who, Obj, Price}).
list()               -> gen_sever:call(?SERVER, list).
%% end:api

%%====================================================================
%% API
%%====================================================================
%%--------------------------------------------------------------------
%% Function: start_link() -> {ok,Pid} | ignore | {error,Error}
%% Description: Starts the server
%%--------------------------------------------------------------------
start_link() ->
    gen_server:start_link({local, ?SERVER}, ?MODULE, [], []).

%%====================================================================
%% gen_server callbacks
%%====================================================================

%%--------------------------------------------------------------------
%% Function: init(Args) -> {ok, State} |
%%                         {ok, State, Timeout} |
%%                         ignore               |
%%                         {stop, Reason}
%% Description: Initiates the server
%%--------------------------------------------------------------------
init([]) ->
    {ok, #state{}}.


%%--------------------------------------------------------------------
%% start:template
%% Function: %% handle_call(Request, From, State) -> {reply, Reply, State} |
%%                                      {reply, Reply, State, Timeout} |
%%                                      {noreply, State} |
%%                                      {noreply, State, Timeout} |
%%                                      {stop, Reason, Reply, State} |
%%                                      {stop, Reason, State}
%% Description: Handling call messages
%% end:template
%%--------------------------------------------------------------------
%% start:handler
%% start:list
handle_call(list, _From, State) ->
    Reply = [{What, Price, Time} || {What, _, Price, Time} <- State],
    {reply, Reply, State};
%% end:list
%% start:sell
handle_call({sell, Obj, Time}, _From, State) ->
    N = count(Obj, State),
    Reply = What = {Obj,N},
    set_timer_to_stop_auction(What, Time),
    State1 = [{What,no,no,Time}|State],
    {reply, Reply, State1};
%% end:sell
%% start:bid
handle_call({bid,Who,Obj,Price}, _From, State) ->
    case make_bid(Who, Obj, Price, State, []) of
	{yes, State1} -> {reply, yes, State1};
	no            -> {reply, no,  State}
    end.
%% end:bid
%% end:handler

%% start:count
count(Obj, L) ->
    length([ x || {{Obj1,_},_,_,_} <- L, Obj1 == Obj]).
%% end:count

%%start:mkbid
make_bid(Who,Obj,Price,[{Obj,Who1,Price1,Time}|T], L)
   when Price > Price1 -> {yes, reverse([{Obj,Who,Price,Time}|T], L)};
make_bid(_Who,Obj,_Price,[{Obj,_Who1,_Price1,_Time}|_T], _L) -> no;
make_bid(Who, Obj, Price, [H|T], L) -> make_bid(Who, Obj, Price, T, [H|L]);
make_bid(_, _, _, [], _) ->  no.
%%end:mkbid

%% start:endauction
set_timer_to_stop_auction(Time, Obj) ->
    spawn(fun() ->
		  receive
		      Time ->
			  gen_sever:info(?SERVER,{end_auction,Obj})
		  end
	  end).
%% end:endauction

%%--------------------------------------------------------------------
%% Function: handle_cast(Msg, State) -> {noreply, State} |
%%                                      {noreply, State, Timeout} |
%%                                      {stop, Reason, State}
%% Description: Handling cast messages
%%--------------------------------------------------------------------
handle_cast(_Msg, State) ->
    {noreply, State}.

%%--------------------------------------------------------------------
%% Function: handle_info(Info, State) -> {noreply, State} |
%%                                       {noreply, State, Timeout} |
%%                                       {stop, Reason, State}
%% Description: Handling all non call/cast messages
%%--------------------------------------------------------------------
%% start:info
handle_info({end_auction,What}, State) ->
    State1 = windup(What, State),
    {noreply, State1}.
%% end:info

%% start:windup
windup(What, [{What,Who,Price,_}|T]) ->
    io:format("~p bought ~p for ~p~n",[Who,What,Price]),
    T;
windup(What, [H|T]) ->
    [H|windup(What, T)];
windup(_, []) ->
    [].
%% end:windup

%%--------------------------------------------------------------------
%% Function: terminate(Reason, State) -> void()
%% Description: This function is called by a gen_server when it is about to
%% terminate. It should be the opposite of Module:init/1 and do any necessary
%% cleaning up. When it returns, the gen_server terminates with Reason.
%% The return value is ignored.
%%--------------------------------------------------------------------
terminate(_Reason, _State) ->
    ok.

%%--------------------------------------------------------------------
%% Func: code_change(OldVsn, State, Extra) -> {ok, NewState}
%% Description: Convert process state when code is changed
%%--------------------------------------------------------------------
code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%%--------------------------------------------------------------------
%%% Internal functions
%%--------------------------------------------------------------------
