%%%-------------------------------------------------------------------
%%% File    : pbay.erl
%%% Author  : joe armstrong <joe@localhost>
%%% Description : money making exerise
%%%
%%% Created : 15 Feb 2008 by joe armstrong <joe@localhost>
%%%-------------------------------------------------------------------
-module(pbay).
-compile(export_all).

-behaviour(gen_server).
-define(SERVER, ?MODULE).

%% API
-export([start_link/0]).

%% gen_server callbacks
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
	 terminate/2, code_change/3]).

%% -record(state, {}).

%%====================================================================
%% API
%%====================================================================
%%--------------------------------------------------------------------
%% Function: start_link() -> {ok,Pid} | ignore | {error,Error}
%% Description: Starts the server
%%--------------------------------------------------------------------
start_link() ->
    gen_server:start_link({local, ?SERVER}, ?MODULE, [], []).

sell(Obj, Time) ->  gen_server:call(?SERVER, {sell, Obj, Time}).

bid(Who, Obj, Price) -> gen_server:call(?SERVER, {bid,  Who, Obj, Price}).

list() -> gen_server:call(?SERVER, list).    

%%====================================================================
%% gen_server callbacks
%%====================================================================

%%--------------------------------------------------------------------
%% Function: init(Args) -> {ok, State} |
%%                         {ok, State, Timeout} |
%%                         ignore               |
%%                         {stop, Reason}
%% Description: Initiates the server
%%--------------------------------------------------------------------
init([]) ->
    {ok, []}.

%%--------------------------------------------------------------------
%% Function: %% handle_call(Request, From, State) -> {reply, Reply, State} |
%%                                      {reply, Reply, State, Timeout} |
%%                                      {noreply, State} |
%%                                      {noreply, State, Timeout} |
%%                                      {stop, Reason, Reply, State} |
%%                                      {stop, Reason, State}
%% Description: Handling call messages
%%--------------------------------------------------------------------
handle_call({sell, Object, Time}, _, State) ->
    State1 = [{Object, Time, []}|State],
    tell_me_at_time(Time, Object),
    {reply,  ok, State1};
handle_call(list, _, State) ->
    Objs  = [N || {N,_,_} <- State],
    {reply, Objs, State};
handle_call({bid, Who, Obj, Price}, _, State) ->
    State1 = add_bid(Obj, Who, Price, State),
    {reply, yes, State1}.

add_bid(O, Who, Price, [{O,Time,L}|T]) ->
    [{O,Time,[{Who,Price}|L]}|T];
add_bid(O, Who, Price, [H|T]) ->
    [H|add_bid(O, Who, Price, T)];
add_bid(_, _, _, []) ->
    [].

tell_me_at_time(Time, Obj) ->
    spawn(fun() ->
		  receive
		  after Time ->
			  gen_server:cast(?SERVER, {expired, Obj})
		  end
	  end).


%%--------------------------------------------------------------------
%% Function: handle_cast(Msg, State) -> {noreply, State} |
%%                                      {noreply, State, Timeout} |
%%                                      {stop, Reason, State}
%% Description: Handling cast messages
%%--------------------------------------------------------------------
handle_cast({expired, Obj}, State) ->
    State1 = finished(Obj, State),
    {noreply, State1}.

finished(Obj, [{Obj,_Time, L}|T]) ->
    io:format("findished:~p bids:~p~n",[Obj,L]),
    T;
finished(Obj, [H|T]) ->
    [H|finished(Obj, T)];
finished(_Obj, []) ->
    [].

%%--------------------------------------------------------------------
%% Function: handle_info(Info, State) -> {noreply, State} |
%%                                       {noreply, State, Timeout} |
%%                                       {stop, Reason, State}
%% Description: Handling all non call/cast messages
%%--------------------------------------------------------------------
handle_info(_Info, State) ->
    {noreply, State}.

%%--------------------------------------------------------------------
%% Function: terminate(Reason, State) -> void()
%% Description: This function is called by a gen_server when it is about to
%% terminate. It should be the opposite of Module:init/1 and do any necessary
%% cleaning up. When it returns, the gen_server terminates with Reason.
%% The return value is ignored.
%%--------------------------------------------------------------------
terminate(_Reason, _State) ->
    ok.

%%--------------------------------------------------------------------
%% Func: code_change(OldVsn, State, Extra) -> {ok, NewState}
%% Description: Convert process state when code is changed
%%--------------------------------------------------------------------
code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%%--------------------------------------------------------------------
%%% Internal functions
%%--------------------------------------------------------------------
