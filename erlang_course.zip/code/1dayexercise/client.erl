-module(client).

-compile(export_all).

%% start(Port) -> {pk, Pid} | error
%%   I become the controlling process

start() ->
    start(1234).

start(Port) ->
    S= self(),
    Pid = spawn(fun() -> connect(S, Port) end),
    receive
	{Pid, Reply} ->
	    Reply
    end.

connect(Parent, Port) ->
    case gen_tcp:connect("localhost", Port, [{packet,4},binary,{active,true},
					     {nodelay,true}]) of
	{ok, Socket}->
	    Parent ! {self(), {ok, self()}},
	    middle_man:start(Parent, Socket);
	_ ->
	    Parent ! {self(), error}
    end.

send(Pid, Msg) ->
    Pid ! {self(), Msg}.

rpc(Pid, Query) ->
    Pid ! {self(), Query},
    receive
	{Pid, Response} ->
	    Response
    end.
