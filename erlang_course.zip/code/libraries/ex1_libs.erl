-module(ex1_libs).
-compile(export_all).

%% start:problem
%%  Write a function
%%   @fetch(X, L) -> Val@ that finds a value @{Key,Val}@ in the list
%% @L@ otherwise raises and exception.
%% end:problem

%% start:test
test() ->
    L = [{fred,no},{bill,yes},{sue,no}],
    yes = fetch(bill, L),
    {'EXIT',_} = (catch fetch(mary, L)),
    hooray.
%% end

%% start:hints
%%   use the "search"  recursion pattern
%% end:hints

%% start:solution
fetch(Key, [{Key,Val}|_]) -> Val;
fetch(Key, [_|T]) -> fetch(Key, T).
%% end:colution
