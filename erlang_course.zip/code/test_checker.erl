-module(test_checker).

-compile(export_all).
-import(lists, [filter/2, foreach/2]).

%% compile all files starting ex*.erl
%% and run the tests in the file

start() ->
    {ok, Files} = file:list_dir("."),
    F1 = filter(fun(I) -> filelib:is_dir(I) end, Files),
    foreach(fun(I) -> dir(I) end, F1),
    init:stop().

dir(I) ->
    ok = file:set_cwd(I),
    (catch check(I)),
    ok = file:set_cwd("..").

check(D) ->
    L  = lib_find:files(".", "*.erl", false),
    L1 = [X || X <- L, is_ex(X)],
    foreach(fun(I) ->
		    case compile:file(I) of
			{ok, Mod} ->
			    %% io:format("D=~p Mod=~p~n",[D,Mod]),
			    case (catch Mod:test()) of
				hooray ->
				    io:format("~p ~p is great~n", [D, I]);
				{'EXIT', Why} ->
				    io:format("**** ~p ~p failed: ~p~n",[D, I,Why]);
				Other ->
				    io:format("**** ~p ~p failed: ~p~n",[D, I,Other])
				    
			    end;
		       O ->
			    io:format("**** ~p ~p compile error ~p~n",[D,I,O])
		    end
	    end, L1).

is_ex("./ex" ++ _) -> true;
is_ex(_) -> false.

    

