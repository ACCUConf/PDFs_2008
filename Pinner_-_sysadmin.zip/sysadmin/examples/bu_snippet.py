# bu_snippet.py

    bu_file = '%s_%s_%s_%s.tgz' % ( payroll, bu_type, prd_txt, date_text, )

    if verbose : ver = 'v'
    else : ver = ''

    cmd = 'cd ..;tar c%szf ../backups/%s data' % ( ver, bu_file, )

    os.system( cmd )
