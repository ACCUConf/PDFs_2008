-module(ex2).
-compile(export_all).

test() ->
    timer:tc(ex2, run, []).

run() ->
    Promise1 = promise(fun() -> fib(40) end),
    Promise2 = promise(fun() -> fib(36) end),
    Promise3 = promise(fun() -> fib(15) end),
    610 = yield(Promise3),
    14930352 = yield(Promise2),
    102334155 = yield(Promise1),
    true.
    
fib(1) -> 1;
fib(2) -> 1;
fib(N) -> fib(N-1) + fib(N-2).

promise(Fun) ->
    %% write this ...
    

yield(Pid) ->
    %% write this ...
    
     

    

