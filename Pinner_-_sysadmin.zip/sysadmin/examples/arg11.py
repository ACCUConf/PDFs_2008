#!/usr/bin/env python
# arg11.py

import argparse

def even_number( s ) :
    value = int( s )
    if value % 2 :
        raise TypeError
    return value

parser = argparse.ArgumentParser()
parser.add_argument( '-e', type=even_number, nargs=1)
values = parser.parse_args()
print 'You gave me an even number : %i' % values.e
