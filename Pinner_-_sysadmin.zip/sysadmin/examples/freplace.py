#!/usr/bin/env python
"""program to find files by pattern and edit them
"""

import sys, argparse
import pyadmin as sa

PARSER = \
 argparse.ArgumentParser( description='find files and optionally edit them')
PARSER.add_argument( '-p', action='store', dest='paths',
                      default='.',
                      help='paths to search',
                   )
PARSER.add_argument( '-i', action='store', dest='inc_patt',
                     default='.*',
                     help='file name pattern to include',
                   )
PARSER.add_argument( '-x', action='store', dest='exc_patt',
                     default=None,
                     help='file name pattern to exclude',
                   )
PARSER.add_argument( '-o', action='store', dest='old',
                     default=None,
                     help='string to search for',
                   )
PARSER.add_argument( '-n', action='store', dest='new',
                     default=None,
                     help='string to replace with',
                   )
PARSER.add_argument( '-b', action='store', dest='bufile',
                     default='editbak.tgz',
                     help='backup file name',
                   )
PARSER.add_argument( '-v', action='store_true', dest='verbose',
                     help='verbose output, lists file names',
                   )
VALUES = PARSER.parse_args()

if not VALUES.paths :
    sys.exit()
FILE_LIST = sa.find( VALUES.paths, VALUES.inc_patt, VALUES.exc_patt,
                     newer_than = None, prt = False, )
if not FILE_LIST :
    sys.stdout.write( 'no matching files\n' )
sys.stdout.write( '%s matching files found\n' % len( FILE_LIST ) )

if not VALUES.old :
    sys.exit()
if not VALUES.new :
    sys.stdout.write( 'please supply a replacement string\n' )
    sys.exit()

CHANGED_FILES = sa.edit_files( FILE_LIST, VALUES.old, VALUES.new,
                               update = False, )
if not CHANGED_FILES :
    sys.stdout.write( 'no files with matching strings (%s)\n' % VALUES.old )
    sys.exit()
if VALUES.verbose :
    sys.stdout.write( 'The following files will be changed:\n' )
    for file_name in CHANGED_FILES :
        sys.stdout.write( '%s\n' % file_name )

sys.stdout.write( '%s files with matching strings found\n' % \
                  len( CHANGED_FILES ) )

sys.stdout.write( 'OK to edit files ? [y|n] [n] >> ' )
OK = sys.stdin.readline().upper().strip()
if OK != 'Y' :
    sys.exit()

sys.stdout.write( 'Taking backup...\n' )
sa.backup( CHANGED_FILES, VALUES.bufile )
sys.stdout.write( 'Backup completed, carrying out edit...\n' )
CHANGED_FILES = sa.edit_files( FILE_LIST, VALUES.old, VALUES.new,
                               update = True, )
sys.stdout.write( '%s files backed up and edited\n' % len( CHANGED_FILES ) )

# *****************************************************************************
