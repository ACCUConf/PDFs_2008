-module(ex1).
-compile(export_all).

%% START:test
test() ->
    {Time, _} = timer:tc(ex1_proc, run, []),
    timing_error(Time, 1200) < 0.5,
    horray.

timing_error(T1, T2) ->
    %% percent error in timing
    (abs(T1 div 1000 -T2)/T2) * 100.

run() ->
    alarm(self(), hello, 1200),
    receive
	hello ->
	    true
    end.

alarm(Pid, Msg, When) ->
%%    you write the rest ...
%% END:test
    end).

    

