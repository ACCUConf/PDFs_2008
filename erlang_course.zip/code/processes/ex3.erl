-module(ex3).
-compile(export_all).
-import(ex2_solution, [fib/1, promise/1, yield/1]).

%% start:body
test() ->
    timer:tc(ex3, run, []).

run() ->
    Promises = lists:map( fun create_promise/1, lists:seq(1, 10)),
    Results =  lists:map(fun ex2_solution:yield/1, Promises),
    io:format("~p~n", [ Results ]).
             
create_promise(_) ->
    promise(fun() -> fib(30) end).
%% end:body