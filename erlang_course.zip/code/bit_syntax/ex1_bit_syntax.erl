-module(ex1_bit_syntax).
-compile(export_all).

%% start:problem
%% <div style="font-size: 75%">
%% The JOE processor has a number of 32 bit instructions, packed like this
%% <pre>
%%       2        5     5     5     5       6
%%     +==============================================+
%% F0  | 00 | opcode | r1 |  r2 |  r2  |  unused      |
%%     +==============================================+
%% F1  | 01 | opcode | r |  val = immediate (20)      |
%%     +==============================================+
%% F2  | 02 | opcode | val = immediate (25)           |
%%     +==============================================+
%% </pre>
%%
%% Here are a few instructions:
%%
%% |f0 | {add, r1, r2, r3} | R[r1] = R[r2] + R[r3] |
%% |f1 | {addi, r1, val}    | R[r1] = R[r1] + val |
%% |f1 | {jz, r1, val}      | if R[r1] == 0 jump to val |
%% |f2 | {jmp, val}        | jump to val |
%%
%% * all immediates are signed integers.
%%
%% * write an assembler and dissassembler for these instructions.
%%
%% </div>
%% end:problem

%% start:test
test() ->
    Code = [{add,1,2,3},
	    {addi,2,1234},
	    {jmp,-10},
	    {jz, 2, -3},
	    {addi,2,-1},
	    {jmp,13456}],
    Asm = asm(Code),
    Code = diss(Asm),
    hooray.
%% end:test

%% start:hints
%% define some macros
%% -define(F0, 0:2).
%% -define(F1, 1:2).
%% -define(F2, 2:2).
%% -define(op(X), X:5).
%% -define(reg(R),R:5).
%% -define(immed(X),X:20/signed-integer).
%% -define(addr(X),X:25/signed-integer).
%%
%% assemble({Op,R1,R2,R3}) ->
%%     Opcode = encode(f0, Op),
%%     <<?F0,?op(Opcode),?reg(R1), ?reg(R2),?reg(R3),0:10>>;
%% ...
%% end:hints

%% start:solution
-define(F0, 0:2).
-define(F1, 1:2).
-define(F2, 2:2).
-define(op(X), X:5).
-define(reg(R),R:5).
-define(immed(X),X:20/signed-integer).
-define(addr(X),X:25/signed-integer).

-define(opcode(Name, Format, Op), opcode(enc, {Format, Name}) -> Op; 
                                  opcode(dec, {Format, Op}) -> Name).

%% compile with erlc -P to see what happens

?opcode(add,  f0, 1);
?opcode(addi, f1, 1);
?opcode(jz,   f1, 2);
?opcode(jmp,  f2, 1);
opcode(X, Y) -> exit({opcode, X, Y}).
    
encode(F, Name)  -> opcode(enc, {F, Name}).
decode(F, Op)    -> opcode(dec, {F, Op}).
 
asm(L) -> list_to_binary([assemble(I) || I <- L]).

assemble({Op,R1,R2,R3}) ->
    Opcode = encode(f0, Op),
    <<?F0,?op(Opcode),?reg(R1), ?reg(R2),?reg(R3),0:10>>;
assemble({Op,R1,X}) ->
    Opcode = encode(f1, Op),
    <<?F1,?op(Opcode),?reg(R1),?immed(X)>>;
assemble({Op,Addr}) ->
    Opcode = encode(f2, Op),
    <<?F2,?op(Opcode),?addr(Addr)>>.

diss(<<?F0,Op:5,R1:5,R2:5,R3:5,_:10,B/binary>>) -> 
    [{decode(f0, Op),R1,R2,R3}|diss(B)];
diss(<<?F1,Op:5,R1:5,?immed(Im),B/binary>>) -> 
    [{decode(f1, Op),R1,Im}|diss(B)];
diss(<<?F2,Op:5,?addr(A),B/binary>>) -> 
    [{decode(f2, Op),A}|diss(B)];
diss(<<>>) -> 
    [].
%% end:solution
