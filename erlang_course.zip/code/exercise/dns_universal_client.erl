-module(dns_universal_client).

-export([connect/1, do/2, close/1]).

connect(Name) ->
    case pico_resolver:locate(Name) of
	{ok, {IP, Port,_TTL}} ->
	    gen_tcp:connect(IP,Port,[binary,{packet,4}]);
	lost ->
	    {error, lost}
    end.

do(Socket, {apply,  _,_,_} = X) -> rpc(Socket, X);
do(Socket, {applyS, _,_,_} = X) -> rpc(Socket, X);
do(Socket, {become, _,_,_} = X) -> cast(Socket, X);
do(Socket, {becomeS,_,_,_} = X) -> cast(Socket, X).

close(Socket) -> gen_tcp:close(Socket).

rpc(Socket, Term) ->
    ok = gen_tcp:send(Socket, term_to_binary(Term)),
    receive
	{tcp, Socket, Data} ->
	    {ok, binary_to_term(Data)};
	{tcp_closed, Socket} ->
	    {error, unknown}
    end.

cast(Socket, Term) ->
    ok = gen_tcp:send(Socket, term_to_binary(Term)),
    receive
	{tcp, Socket, Data} ->
	    {ok, binary_to_term(Data)};
	{tcp_closed, Socket} ->
	    {error, unknown}
    end.
