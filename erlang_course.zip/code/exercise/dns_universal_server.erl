-module(dns_universal_server).

-compile(export_all).

test() ->
    start(joe).

start(Name) ->
    spawn_link(fun() -> run(Name) end).

run(Name) ->
    {ok, Listen} = gen_tcp:listen(0, [binary,{packet,4},
				      {reuseaddr,true},{active,true}]),
    {ok, PortL} = inet:port(Listen),
    io:format("Universal server for:~p listening on port:~p~n",[Name,PortL]),
    pico_resolver:signon(Name, PortL, 300),
    %% spawn a connector
    spawn_link(fun() -> par_connect(Listen) end),
    %% We have to sleep here otherwise the processes will terminate
    %% and the Listen socket will be closed 
    sleep(infinity).

%% page 248
par_connect(Listen) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen) end),
    loop(Socket).

loop(Socket) ->
    receive
	{tcp, Socket, Data} ->
	    Term = binary_to_term(Data),
	    case Term of
		{apply, Mod, Func, Args} ->
		    Val = apply(Mod, Func, Args),
		    gen_tcp:send(Socket, term_to_binary(Val)),
		    loop(Socket);
		{applyS, Mod, Func, Args} ->
		    Val = apply(Mod, Func, [Socket|Args]),
		    gen_tcp:send(Socket, term_to_binary(Val)),
		    loop(Socket);
		{become, Mod, Func, Args} ->
		    apply(Mod, Func, Args);
		{becomeS, Mod, Func, Args} ->
		    apply(Mod, Func, [Socket|Args])
	    end
    end.

sleep(T) ->
    receive
    after T ->
	    void 
    end.
