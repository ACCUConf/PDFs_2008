-module(ex5_seq).
-compile(export_all).
-import(lists, [reverse/1]).


-define(IN(X,Min,Max), X >= Min, X =< Max).
-define(DIGIT(X), X >= $0, X =< $9).
-define(LETTER(X), X >= $a, X =< $z ;  X >= $A, X =< $Z).
-define(UPPER(X),  X >= $A, X =< $Z).

%% problem
%%  write a tokeniser to tokenise a trings into lists of tokens
%% end

%% test cases
test() ->
    [{int,123},{atom,"abc"}] = tokenize("123 abc"),
    [{int,123},{str,"abc"},{str,"def"}] = tokenize("123 'abc' \"def\" "),
    ['(', {var,"X"},')','=',{int,222}]  = tokenize("(X) = 222"), 
    hooray.
%% end

%% hints
%%
%% end

%% solution
tokenize(Str) ->
    tokenize(Str, []).

tokenize([H|T], L) when H =:= $\s; H =:= $\n; H =:= $\t; H =:= $\r ->
    tokenize(T, L);
tokenize([H|T], L) when ?DIGIT(H) ->
    {Int, T1} = collect_integer(T, H-$0),
    tokenize(T1, [{int,Int}|L]);
tokenize([H|T], L) when ?UPPER(H) ->
    {Atom, T1} = collect_atom(T, [H]),
    tokenize(T1, [{var,Atom}|L]);
tokenize([H|T], L) when ?LETTER(H) ->
    {Atom, T1} = collect_atom(T, [H]),
    tokenize(T1, [{atom,Atom}|L]);
tokenize([$"|T], L) ->
    {Str, T1} = collect_string(T, $", []),
    tokenize(T1, [{str,Str}|L]);
tokenize([$'|T], L) ->
    {Str, T1} = collect_string(T, $', []),
    tokenize(T1, [{str,Str}|L]);
tokenize([H|T], L) ->
    tokenize(T, [list_to_atom([H])|L]);
tokenize([], L) ->
    reverse(L).
   
collect_atom([H|T], L) when ?IN(H,$a,$z) -> collect_atom(T, [H|L]);
collect_atom([H|T], L) when ?IN(H,$a,$z) -> collect_atom(T, [H|L]);
collect_atom([H|T], L) when ?IN(H,$0,$9) -> collect_atom(T, [H|L]);
collect_atom([$-|T], L) -> collect_atom(T, [$-|L]);
collect_atom([$_|T], L) -> collect_atom(T, [$_|L]);
collect_atom(T, L)      -> {reverse(L), T}.
    
collect_string([Stop|T], Stop, L) -> {reverse(L), T};
collect_string([H|T], Stop, L)    -> collect_string(T, Stop, [H|L]);
collect_string([], _, L)          -> {reverse(L),  []}.

collect_integer([H|T], N) when ?IN(H, $0, $9) ->
    collect_integer(T, N*10+H-$0);
collect_integer(S, N) ->
    {N, S}.

%% end
