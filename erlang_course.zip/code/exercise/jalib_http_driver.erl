-module(jalib_http_driver).

-import(lists, [member/2]).

-compile(export_all).

%% the nano http server
%% (smaller thasn pico).

%% to start
%% jalib_nano_http:start(Port, Fun(Handler))

start(Port, Fun, Arg) ->
    {ok, Listen} = gen_tcp:listen(Port, 
				  [binary,
				   %% {dontroute, true},
				   {nodelay,true},
				   {packet, 0},
				   {reuseaddr, true}, 
				   {active, false}]),
    io:format("listen port:~p~n",[Port]),
    spawn(fun() -> par_connect(Listen, Fun, Arg) end).

-record(req, {verb, keepAlive, path, vsn, length=0, body=(<<>>)}).

par_connect(Listen, Fun, Arg) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen, Fun, Arg) end),
    inet:setopts(Socket, [{packet,http},{active,false}]),
    loop(Socket, Fun, Arg).

loop(Socket, Fun, Arg) ->
    R = get_request(Socket, #req{}),
    R1 = get_body(Socket, R),
    io:format("R1=~p~n",[R1]),
    do_request(Socket, R1, Fun, Arg),
    loop(Socket, Fun, Arg).
    
get_request(Socket, R) ->
    Val = gen_tcp:recv(Socket, 0, 60000), 
    %% io:format("Received:~p~n",[Val]),
    case Val of
	{ok, {http_request, Verb, Path, Vsn}} ->
	    %% {File, Args} = pico_utils:parse_uri(Uri),
	    R1 = R#req{verb=Verb, path=Path, vsn=Vsn},
	    get_request(Socket, R1);
	{ok, {http_header,_,'Content-Length',_,Str}} ->
	    Length = list_to_integer(Str),
	    get_request(Socket, R#req{length=Length});
	{ok, {http_header,_,'Connection',_,Bool}} ->
	    get_request(Socket, R#req{keepAlive=Bool});
	{ok, {http_header,_,_,_,_}} ->
	    get_request(Socket, R);
	{ok, http_eoh} ->
	    R;
	{error, timeout} ->
	    exit(normal);
	X ->
	    io:format("invalid *** X=~p~n",[X]),
	    exit(eBadRequest)
    end.

get_body(Socket, R) ->
    case R#req.length of 
	0 -> R;
	N when N > 0 ->
	    inet:setopts(Socket, [{packet, raw}]),
            case gen_tcp:recv(Socket, N, 60000) of
                {ok, Bin} ->
		    R#req{body=Bin};
		_ ->
		    exit(eProtocol)
	    end
    end.

do_request(Socket, #req{verb=Cmd,path=P,body=D,keepAlive=K}, Fun, Arg) ->
    case P of
	{abs_path, Uri} ->
	    {File, Args} = pico_utils:parse_uri(Uri),
	    try 
		begin 
		    {Code, Type, Body} = Fun(Cmd, File, Args, 
					     D, Arg),
		    send_reply(Socket, Code, Type, Body)
		end
	    catch
		What:Why ->
		    Trace = erlang:get_stacktrace(),
		    io:format("<h1>Error:~p ~p ~p~n</h1>",[What, Why, Trace]),
		    send_reply(Socket, 400, "text/html",
			       "<p>Error see terminal log for why")
	    end
    end,
    io:format("K=~p~n",[K]),
    case K of
	"keep-alive" ->
	    void;
	_ ->
	    exit(terminated)
    end.

send_reply(Socket, Code, Type, Body) ->
    B = list_to_binary(Body),
    Size = size(B),
    Headers = ["Content-Type: ", Type, "\r\n",
	       "Content-Length: ", i2s(Size),"\r\n"],
    
    Resp = ["HTTP/1.1 ", i2s(Code), "OK\r\n",
            Headers,
            "\r\n",
            Body],
    gen_tcp:send(Socket, Resp).

i2s(I) ->
    integer_to_list(I).

mime_type(FileName) ->
    case filename:extension(FileName) of
	".GIF"  -> "image/gif";
	".gif"  -> "image/gif";
	".JPG"  -> "image/jpeg";
	".jpg"  -> "image/jpeg";
	".jpeg" -> "image/jpeg";
	".JPEG" -> "image/jpeg";
	".css"  -> "text/css";
	".swf"  -> "application/x-shockwave-flash";
	_ -> "text/html"
    end.

send_file(File, Args, DocRoot) ->
    io:format("send file File:~p Args:~p Docroot:~p~n",[File,Args,DocRoot]),
    FileName = make_safe_path(DocRoot, File),
    io:format("Fullname = ~p~n",[FileName]),
    {ok, Bin} = file:read_file(FileName),
    Type = mime_type(FileName),
    {400,Type,[Bin]}.

make_safe_path(Docroot, File) ->
    io:format("make safe path: ~p ~p~n",[Docroot, File]),
    Z = string:tokens(File, "/"), 
    case member("..", Z) of
	true -> exit(badpath);
	false -> void
    end,
    filename:join(Docroot, filename:join(Z)).

show(Args) ->
    ["<pre>", quote(lists:flatten(io_lib:format("~p~n",[Args]))), "</pre>"].

quote("<" ++ T) -> "&lt;" ++ quote(T);
quote([H|T]) -> [H|quote(T)];
quote([]) -> [].
