-module(simple_coordinate_server).

-compile(export_all).

test() ->
    Port = 1234,
    Info = {joe, 23, 10},
    start(Port, Info).

start(Port, Info) ->
    io:format("Starting a coordinate server on Port:~p~n",[Port]),
    io:format("My information is: ~p~n",[Info]),
    spawn_link(fun() -> run(Port, Info) end).

run(Port, Info) ->
    {ok, Listen} = gen_tcp:listen(Port, [binary,{packet,4},
					 {reuseaddr,true},{active,true}]),
    %% spawn a connector
    spawn_link(fun() -> par_connect(Listen, Info) end),
    %% We have to sleep here otherwise the processes will terminate
    %% and the Listen socket will be closed 
    sleep(infinity).

%% page 248
par_connect(Listen, Info) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_connect(Listen, Info) end),
    loop(Socket, Info).

loop(Socket, Info) ->
    receive
	{tcp, Socket, Data} ->
	    whereAreYou = binary_to_term(Data),
	    gen_tcp:send(Socket, term_to_binary(Info)),
	    loop(Socket, Info)
    end.

sleep(T) ->
    receive
    after T ->
	    void 
    end.
