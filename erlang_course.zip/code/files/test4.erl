-module(test4).

-compile(export_all).

read_config() ->
    {ok, [{host,Host,port,Port}]} = file:consult("file1"),
    {Host, Port}.
