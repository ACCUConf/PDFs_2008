#!/usr/bin/env python

import threading, time, sys

def test_func( numeric=True ):
    """A simple function which sends something to stdout for 10 seconds"""
    chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if numeric :
        delay = 1
    else :
        delay = 0.3
    for i in range( 10 ) :
        if numeric :
            sys.stdout.write( '%s ' % i )
        else :
            sys.stdout.write( chars[ i ] )
        sys.stdout.flush()
        time.sleep( delay )
    sys.stdout.write( '\n' )
    return

t1 = threading.Thread( name="num thread", target=test_func )
t2 = threading.Thread( name="char thread", target = test_func,
                       args=(), kwargs={'numeric':False,} )
t1.start()
t2.start()

sys.stdout.write( 'S' )
t2.join()
sys.stdout.write( '*' )

while t1.isAlive() : pass
sys.stdout.write( 'Z\n' )

