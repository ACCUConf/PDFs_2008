-module(pico_resolver).

-export([test/0, signon/3, locate/1]).

-include("pico_dns.hrl").

test() ->
    Dj = 45, Dd = 60,
    io:format("Signon joe at port 1000 time to live ~w seconds~n",[Dj]),
    io:format("Signon dave at port 2000 time to live ~w seconds~n", [Dd]),
    signon(joe,  1000, Dj),
    signon(dave, 2000, Dd),
    init:stop().

signon(Name, Port, TTL) ->
    {ok, Socket} = gen_udp:open(0, [binary]),
    Request = term_to_binary({register, Name, Port, TTL}),
    io:format("sending register to:~p ~p~n",[?SERVER_IP,?SERVER_PORT]),
    ok = gen_udp:send(Socket, ?SERVER_IP, ?SERVER_PORT, Request).

locate(Name) ->
    {ok, Socket} = gen_udp:open(0, [binary]),
    Request = term_to_binary({whereis, Name}),
    ok = gen_udp:send(Socket, ?SERVER_IP, ?SERVER_PORT, Request),
    receive
	{udp, Socket,_IP,_Port,Bin} ->
	    Val = binary_to_term(Bin),
	    gen_udp:close(Socket),
	    Val
    after 5000 ->
	    gen_udp:close(Socket),
	    timeout
    end.
