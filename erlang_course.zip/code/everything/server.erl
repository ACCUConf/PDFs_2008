-module(server).

%% start:api
-export([start/0, register_resource/1, unregister_resource/1, 
	 whereis_resource/1]).

start() -> register(resource_allocator, fun() -> go() end).

register_resource(What)   -> rpc({register,What,self()}).
unregister_resource(What) -> rpc({unregister, What, self()}).
whereis_resource(What)    -> rpc({whereis, What}).
%% end:api

%% start:go
go() ->
    process_flag(trap_exit, true),
    loop([]).
%% end:go

%% start:rpc
rpc(Q) ->
    resource_allocator ! {self(), Q},
    receive
	{resource_allocator, Reply} ->
	    Reply
    end.
%% end:rpc

%% start:loop
loop(L) ->
    receive
	{From, {register, What, Pid}} ->
	    link(Pid),
	    From ! {resource_allocator, ack},
	    loop([{What,Pid}|L]);
	{From, {unregister, What, Pid}} ->
	    L1 = remove({What,Pid}, L),
	    case count_registrations(Pid, L1) of
		0 -> unlink(Pid);
		_ -> void
	    end,
	    From ! {resource_allocator, ack},
	    loop(L1);
%% end:loop
%% start:loop1
	{From, {whereis, Name}} ->
	    Val = locate(Name, L),
	    From ! {resource_allocator, Val},
	    loop(L);
	{'EXIT', Pid, _} ->
	    L1 = remove_allocations(Pid, L),
	    loop(L1)
    end.
%% end:loop1

%% start:misc
remove(H, [H|T]) -> T;
remove(H, [X|T]) -> [X|remove(H, T)];
remove(_, [])    -> [].

count_registrations(Pid, [{_,Pid}|T]) -> 
    1 + count_registrations(Pid, T);
count_registrations(Pid, [_|T]) -> 
    count_registrations(Pid, T);
count_registrations(_, []) -> 
    0.
%% end:misc

%% start:misc1    
locate(What, [{What,Pid}|_]) -> {ok, Pid};
locate(What, [_|T])          -> locate(What, T);
locate(_, [])                -> error.

remove_allocations(Pid, [{_,Pid}|T]) -> 
    remove_allocations(Pid, T);
remove_allocations(Pid, [H|T]) -> 
    [H|remove_allocations(Pid, T)];
remove_allocations(_, []) -> 
    [].
%% end:misc1

     
    
    

		    
					 
