%% start:start
-module(spy).
-export([start/0, start/3,accept/3]).

-define(TCP_OPTIONS,[list, {packet, 0}, {active, true}, {reuseaddr, true}]).

%% use to record tcp sessions to a disk file

%% start(2030, "www.a.b.c", 80)
%%     sets up a monitor on 2030
%%     connecting to localhost:2030
%%     will then connect to www.a.b.c port 80

start() ->
    start(2000, "www.google.com", 80). 

start(LPort,RHost,RPort)->
   case gen_tcp:listen(LPort,?TCP_OPTIONS) of
       {ok, ListenSocket} -> 
	   spawn(fun() -> accept(ListenSocket,RHost,RPort) end);
       {error,Why}->
	   io:format("socket error0:~p~n",[Why])
   end.
%% you write the rest ...
%% end:start
accept(ListenSocket,RHost,RPort) ->
   case gen_tcp:accept(ListenSocket) of
       {ok, AcceptSocket}->
           spawn(fun() -> accept(ListenSocket, RHost, RPort) end),
           case gen_tcp:connect(RHost,RPort,?TCP_OPTIONS) of
               %%   ConnectSocket:server to remote ;AcceptSocket:client to server
               {ok,ConnectSocket}->
                   loop(ConnectSocket,AcceptSocket);
               {error,Reason} ->
                   io:format("1.~p~n",[Reason])
           end;
       {error,Why}->io:format("socket error1:~p~n",[Why])
   end.

loop(A, B) ->
   receive
       {tcp, A, Data} ->
	   io:format("a sent:~p~n", [Data]),
	   gen_tcp:send(B, Data), 
	   loop(A, B);
       {tcp, B, Data} -> 
	   io:format("b sent:~p~n", [Data]),
	   gen_tcp:send(A, Data), 
	   loop(A, B);
       {tcp_closed, A} -> 
	   io:format("a closed:~n", []),
	   gen_tcp:close(B);
       {tcp_closed, B} -> 
	   io:format("b closed:~n", []),
	   gen_tcp:close(A)
   end.
