-module(server).

-export([start/0]).

start() ->
    start(1234).

start(Port) ->
    spawn(fun() -> start1(Port) end).

start1(Port) ->
    {ok, Listen} = gen_tcp:listen(Port, [{packet,4}, binary, {reuseaddr, true},
					 {nodelay,true}, {active,true}]),
    io:format("Server started listening to port:~p~n",[Port]),
    Multi = multi_server:start(),
    spawn(fun() -> par_loop(Listen, Multi) end),
    sleep().

sleep() ->
    receive after infinity -> true end.

par_loop(Listen, Multi) ->
    {ok, Socket} = gen_tcp:accept(Listen),
    spawn(fun() -> par_loop(Listen, Multi) end),
    middle_man:start(Multi, Socket).
